<?php
declare(strict_types=1);

return [
    'app.title' => 'Call-markaz analitikasi',
    'nav.dashboard' => 'Dashboard',
    'nav.smartomato' => 'Smartomato',
    'nav.telegram_bot' => 'Telegram bot',
    'nav.others' => 'Boshqalar',
    'nav.taxi' => 'Taxi',
    'nav.errors' => 'Xatolar',
    'nav.operator_sales' => 'Operator savdo',
    'nav.operators' => 'Operatorlar',
    'nav.settings' => 'Sozlamalar',
    'nav.logout' => 'Chiqish',

    'login.title' => 'Kirish',
    'login.username' => 'Login',
    'login.password' => 'Parol',
    'login.submit' => 'Kirish',
    'login.error' => 'Login yoki parol noto‘g‘ri',

    'role.admin' => 'Admin',
    'role.manager' => 'Call-markaz menejeri',
];

